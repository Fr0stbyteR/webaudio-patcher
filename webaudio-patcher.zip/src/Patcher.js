import {
    EventEmitter
} from "events";
import BaseObj from "./BaseObj.js"
import WAObj from "./WAObj.js"
let Packages = {BaseObj, WAObj};
export default class Patcher extends EventEmitter {
    constructor(patcher) {
        super();
        this.lines = {};
        this.boxes = {};
        this.data = {};
        if (patcher == undefined) return;
        // Patcher
        this.indexCount = patcher.indexCount;
        this.bgcolor = patcher.bgcolor;
        this.editing_bgcolor = patcher.editing_bgcolor;
        // Boxes & data
        for (const id in patcher.boxes) {
            this.createBox(patcher.boxes[id]);
        }
        console.log(this);
        // Lines
        for (const id in patcher.lines) {
            this.createLine(patcher.lines[id]);
        }
        this.emit("readyPatch", this);
    }

    static fromMaxPatcher(maxPatcher) {
        let maxBoxes = maxPatcher.patcher.boxes;
        let maxLines = maxPatcher.patcher.lines;

        let patcher = {
            lines: {},
            boxes: {},
            data: {}
        };
        patcher.bgcolor = rgbaMax2Css(maxPatcher.patcher.bgcolor);
        patcher.editing_bgcolor = rgbaMax2Css(maxPatcher.patcher.editing_bgcolor);
        patcher.indexCount = 0;
        for (let i = 0; i < maxLines.length; i++) {
            let lineArgs = maxLines[i]["patchline"];
            let line = {
                src: [lineArgs.source[0].replace(/obj/, "box"), lineArgs.source[1]],
                dest: [lineArgs.destination[0].replace(/obj/, "box"), lineArgs.destination[1]]
            };
            let id = line.src[0] + "_" + line.src[1] + "__" + line.dest[0] + "_" + line.dest[1];
            patcher.lines[id] = line;
        }

        for (let i = 0; i < maxBoxes.length; i++) {
            let maxBox = maxBoxes[i]["box"];
            let numID = maxBox.id.match(/\d+/)[0];
            if (numID > patcher.indexCount) patcher.indexCount = numID;
            let id = "box-" + numID;
            let box = {
                id: id,
                name: id,
                key: id,
                class: "",
                inlets: maxBox.numinlets,
                outlets: maxBox.numoutlets,
                patching_rect: maxBox.patching_rect,
                text: "",
                args: [],
                props: {}
            }
            if (maxBox.hasOwnProperty("text")) {
                box.text = maxBox.text;
                Object.assign(box, parseObjText(maxBox.text));
            }
            // get the name out to root
            if (box.hasOwnProperty("props") && box.props.hasOwnProperty("name")) {
                box.name = box.props.name;
                delete box.props.name;
            }
            patcher.boxes[id] = box;
        }
        return patcher;
    }

    createBox(props) {
        let box = new Box(props, this);
        this.boxes[box.id] = box;
        this.emit("createBox", box);
        return box;
    }

    createLine(props) {
        let line = new Line(props, this);
        this.lines[line.id] = line;
        this.emit("createLine", line);
        return line;
    }

    changeLine(id, srcID, srcOutlet, destID, destInlet) {
        //patcher.lines[id].source = srcID
    }

    createObject(box) {
        let obj;
        let str = box.class;
        if (str.length == 0) obj = new Packages.BaseObj.EmptyObject(box, this);
        else {
            try {
                let arr = str.split(".");
                let fn = Packages;
                for (var i = 0, len = arr.length; i < len; i++) {
                    fn = fn[arr[i]];
                }
                obj = new fn(box, this);
            } catch (e) {
                obj = new Packages.BaseObj.InvalidObject(box, this);
            }
        }
        this.emit("createObject", obj);
        return obj;
    }

    getLinesBySrcID(srcID, srcOutlet) {
        let result = [];
        for (const id in this.lines) {
            const line = this.lines[id];
            if (line.src[0] == srcID && (line.src[1] == srcOutlet || srcOutlet == undefined)) {
                result.push(id);
            }
        }
        return result;
    }

    getLinesByDestID(destID, destInlet) {
        let result = [];
        for (const id in this.lines) {
            const line = this.lines[id];
            if (line.dest[0] == destID && (line.dest[1] == destInlet || destInlet == undefined)) {
                result.push(id);
            }
        }
        return result;
    }

    getLinesByIO(srcID, destID, srcOutlet, destInlet) {
        let result = [];
        for (const id in this.lines) {
            const line = this.lines[id];
            if (line.src[0] == srcID && (line.src[1] == srcOutlet || srcOutlet == undefined)) {
                if (line.dest[0] == destID && (line.dest[1] == destInlet || destInlet == undefined)) {
                    result.push(id);
                }
            }
        }
        return result;
    }

    getObjByID(id) {
        return this.data[this.boxes[id].name][this.boxes[id].class];
    }
    getNameByID(id) {
        return this.boxes[id].name;
    }
    getIDsByName(name, className) {
        return this.data[name][className].boxes;
    }
}

class Box {
    constructor(props, patcher) {
        this._patcher = patcher;
        this.id = props.id;
        this.name = props.name;
        this.key = props.key;
        this.class = props.class;
        this.inlets = props.inlets;
        this.outlets = props.outlets;
        this.patching_rect = props.patching_rect;
        this.text = props.text || "";
        this.args = props.args;
        this.props = props.props;

        if (!this._patcher.data.hasOwnProperty(this.name)) this._patcher.data[this.name] = {};
        if (!this._patcher.data[this.name].hasOwnProperty(this.class)) {
            this._patcher.data[this.name][this.class] = this._patcher.createObject(this);
        } else {
            this._patcher.data[this.name][this.class].addBox(this.id);
        }
    }
    changeText(textIn) {
        if (textIn == this.text) return this;
        this._patcher.data[this.name][this.class].removeBox(this.id);
        let props = parseObjText(textIn);
        this.class = props.class;
        this.args = props.args;
        this.props = props.props;
        if (!this._patcher.data.hasOwnProperty(this.name)) this._patcher.data[this.name] = {};
        if (!this._patcher.data[this.name].hasOwnProperty(this.class)) {
            this._patcher.data[this.name][this.class] = this._patcher.createObject(this);
        } else {
            this._patcher.data[this.name][this.class].addBox(this.id);
        }
    }
}

class Line {
    constructor(props, patcher) {
        this._patcher = patcher;
        this.src = [props.src[0], props.src[1]];
        this.dest = [props.dest[0], props.dest[1]];
        this.id = props.src[0] + "_" + props.src[1] + "__" + props.dest[0] + "_" + props.dest[1];
        let srcObj = this.srcObj;
        let destObj = this.destObj;
        srcObj.connectedOutlet(this.src[1], destObj, this.dest[1], this.id);
        destObj.connectedInlet(this.dest[1], srcObj, this.src[1], this.id);
        destObj.on(this.id, (data) => {
            destObj.fn(data, this.dest[1])
        });
    }
    setSrc(args) {
        let {
            srcID,
            srcOutlet
        } = args;
        if (srcID == this.src[0] && srcOutlet == this.src[1]) return;
        let srcObj = this.srcObj;
        let destObj = this.destObj;
        destObj.removeAllListeners(this.id);
        srcObj.disconnectedOutlet(this.src[1], destObj, this.dest[1], this.id);
        destObj.disconnectedInlet(this.dest[1], srcObj, this.src[1], this.id);
        this.src = [srcID, srcOutlet];
        this.id = this.src[0] + "_" + this.src[0] + "__" + this.dest[0] + "_" + this.dest[1];
        srcObj = this.srcObj;
        srcObj.connectedOutlet(this.src[1], destObj, this.dest[1], this.id);
        destObj.connectedInlet(this.dest[1], srcObj, this.src[1], this.id);
        destObj.on(this.id, (data) => {
            destObj.fn(data, this.dest[1])
        });
        return this;
    }
    setDest(args) {
        let {
            destID,
            destInlet
        } = args;
        let srcObj = this.srcObj;
        let destObj = this.destObj;
        destObj.removeAllListeners(this.id);
        srcObj.disconnectedOutlet(this.src[1], destObj, this.dest[1], this.id);
        destObj.disconnectedInlet(this.dest[1], srcObj, this.src[1], this.id);
        this.dest = [destID, destInlet];
        this.id = this.src[0] + "_" + this.src[0] + "__" + this.dest[0] + "_" + this.dest[1];
        destObj = this.destObj;
        srcObj.connectedOutlet(this.src[1], destObj, this.dest[1], this.id);
        destObj.connectedInlet(this.dest[1], srcObj, this.src[1], this.id);
        destObj.on(this.id, (data) => {
            destObj.fn(data, this.dest[1])
        });
        return this;
    }
    destroy() {
        let srcObj = this.srcObj;
        let destObj = this.destObj;
        destObj.removeAllListeners(this.id);
        srcObj.disconnectedOutlet(this.src[1], destObj, this.dest[1], this.id);
        destObj.disconnectedInlet(this.dest[1], srcObj, this.src[1], this.id);
        delete this._patcher.lines[this.id];
    }
    get srcID() {
        return this.src[0];
    }
    get srcOutlet() {
        return this.src[1];
    }
    get destID() {
        return this.dest[0];
    }
    get destOutlet() {
        return this.dest[1];
    }
    get srcObj() {
        return this._patcher.getObjByID(this.src[0]);
    }
    get destObj() {
        return this._patcher.getObjByID(this.dest[0]);
    }
}

let rgbaMax2Css = function (arr) {
    let res = [];
    for (let i = 0; i < 3; i++) {
        res[i] = parseInt(arr[i] * 255);
    }
    if (arr.length == 4) res[3] = arr[3];
    return res;
}

let parseObjText = function (strIn) {
    const REGEX = /[^\s"]+|"([^"]*)"/gi;
    let strArray = [], match;
    do {
        //Each call to exec returns the next regex match as an array
        match = REGEX.exec(strIn);
        if (match != null) {
            //Index 1 in the array is the captured group if it exists
            //Index 0 is the matched text, which we use if no captured group exists
            strArray.push(match[1] ? match[1] : match[0]);
        }
    } while (match != null);
    let objOut = {
        class: "",
        args: [],
        props: {}
    }
    let lastProp;
    if (strArray.length) objOut.class = strArray.shift();
    while (strArray.length) {
        const e = strArray.shift();
        if (typeof lastProp == "undefined" && e.charAt(0) != "@") {
            objOut.args.push(e);
            continue;
        }
        if (e.length > 1 && e.charAt(0) == "@") {
            lastProp = e.substr(1);
            objOut.props[lastProp] = [];
            continue;
        }
        objOut.props[lastProp].push(e);
    }
    for (const key in objOut.props) {
        if (objOut.props[key].length == 0) objOut.props[key] = true;
        else if (objOut.props[key].length == 1) objOut.props[key] = parseToPrimitive(objOut.props[key][0]);
    }
    return objOut;
}

function parseToPrimitive(value) {
    try {
        return eval(value);
    } catch (e) {
        return value;
    }
}