import BaseObj from "./BaseObj";

class WANode extends BaseObj.EmptyObject {
    constructor(box, patcher) {
        super(box, patcher);
        if (!this._patcher.hasOwnProperty("audioCtx"))
            this._patcher.audioCtx = new(window.AudioContext || window.webkitAudioContext)();
        this.audioCtx.destination.channelInterpretation = "discrete";
        this.node;

    }
    connectedInlet(inlet, srcObj, srcOutlet, lineID) {
        if (srcObj.hasOwnProperty("node") && srcObj.node instanceof AudioNode) {
            srcObj.node.connect(this.node, srcOutlet, inlet);
        }
    }
    disconnectedInlet(inlet, srcObj, srcOutlet, lineID) {
        if (srcObj.hasOwnProperty("node") && srcObj.node instanceof AudioNode) {
            srcObj.node.disconnect(this.node, srcOutlet, inlet);
        }
    }
    get audioCtx() {
        return this._patcher.audioCtx;
    }
}

class Oscillator extends WANode {
    constructor(box, patcher) {
        super(box, patcher);
        this.node = this.audioCtx.createOscillator();
        this.inlets = 2;
        this.outlets = 1;
        this.node.type = box.props.type || "sine";
        if (typeof box.props.frequency == "number") {
            this.node.frequency.setValueAtTime(box.props.frequency, this.audioCtx.currentTime);
        }
        this.node.start();
    }

}

class Destination extends WANode {
    constructor(props, patcher) {
        super(props, patcher);
        this.node = this.audioCtx.destination;
        this.inlets = 1;
        this.outlets = 0;
    }

}

export default {
    Oscillator,
    Destination
}