import $ from 'jquery';
import React from 'react';
import ReactDOM from 'react-dom';
import {
	content
} from "./maxpat.js";
import Patcher from "./Patcher.js";
import UIObj from "./UIObj.jsx";
import "jquery-ui/ui/widgets/draggable.js";
import "jquery-ui/ui/widgets/resizable.js";
import "jquery-ui/themes/base/draggable.css";
import "jquery-ui/themes/base/resizable.css";
window.$ = window.JQuery = $;

let patcher = new Patcher(Patcher.fromMaxPatcher(content));

$(document).ready(function () {
	$("body").css("background-color", "rgba(" + patcher.bgcolor.join(",") + ")")
	
	let boxesDOM = [];
	for (const id in patcher.boxes) {
		let box = patcher.boxes[id];
		let obj = patcher.getObjByID(id);
		boxesDOM.push(React.createElement(obj.ui, box, null));
	}
	ReactDOM.render(boxesDOM, $(".boxes")[0]);

	let linesDOM = []; 
	for (const id in patcher.lines) {
		const line = patcher.lines[id];
		let startOffset = $("#" + line.src[0]).find(".object-outlet").eq(line.src[1]).addClass("object-port-connected").offset();
		let destOffset = $("#" + line.dest[0]).find(".object-inlet").eq(line.dest[1]).addClass("object-port-connected").offset();
		linesDOM.push(React.createElement(UIObj.Line, {
			id: id,
			key: id,
			start: [startOffset.left + 5.5, startOffset.top + 5.5],
			dest: [destOffset.left + 5.5, destOffset.top + 5.5]
		}, null));
		//<Line id={id} key={id} start={[startOffset.left + 4, startOffset.top + 4]} dest={[destOffset.left + 4, destOffset.top + 4]} />
	}
	ReactDOM.render(linesDOM, $(".lines")[0]);
	for (const id in patcher.lines) {
		updateLine(id);
	}

	$(".object").draggable({
		drag: (event, ui) => {
			updateLineByObj(ui.helper.attr("id"));
		}
	}).resizable({
		handles: "e, w",
		resize: (event, ui) => {
			updateLineByObj(ui.helper.attr("id"));
		}
	}).resizable("disable");
	$(".line-handler").draggable({
		drag: (event, ui) => {
			let id = ui.helper.parent().attr("id");
			let isSrc = ui.helper.hasClass("line-handler-src");
			ui.helper.parent().find(".line-handler").addClass("hidden");
			dragLine(id, isSrc, ui.offset);
			let closest = findClosestPort(ui.offset, isSrc, patcher.lines[id][isSrc ? "src" : "dest"]);
			$(".object-port-highlight").removeClass("object-port-highlight");
			if (closest.length) {
				$("#" + closest[0]).find(isSrc ? ".object-outlet" : ".object-inlet").eq(closest[1]).addClass("object-port-highlight");
			}
		},
		stop: (event, ui) => {
			$(".object-port-highlight").removeClass("object-port-highlight");
			ui.helper.parent().find(".line-handler").removeClass("hidden");
			updateLine(ui.helper.parent().attr("id"));
		}
	});
	$(document).on("focus", ".object", (e) => {
		$(e.currentTarget).resizable("enable");
		$(e.currentTarget).find("p").css("pointer-events", "auto");
	}).on("blur", ".object", (e) => {
		$(e.currentTarget).resizable("disable");
		$(e.currentTarget).find("p").css("pointer-events", "none");
	}).on("click", ".object:focus p", (e) => {
		$(e.currentTarget).attr("contenteditable", true).css("cursor", "text").parent().draggable("disable");
		let range = document.createRange();
		let selection = window.getSelection();
		range.selectNodeContents($(e.currentTarget)[0]);
		selection.removeAllRanges();
		selection.addRange(range);
	}).on("blur", ".object p", (e) => {
		$(e.currentTarget).attr("contenteditable", false).css("cursor", "default").parent().draggable("enable");
		window.getSelection().removeAllRanges();
	}).on("focus", ".line", (e) => {
		updateLine($(e.currentTarget).attr("id"));
		$(e.currentTarget).find(".line-handler").removeClass("hidden");
	}).on("blur", ".line", (e) => {
		$(e.currentTarget).find(".line-handler").addClass("hidden");
	}).on("mouseup", ".line-handler", (e) => {
		updateLine($(e.currentTarget).parent().attr("id"))
	});
});

let dragLine = function (id, isSrc, offset) {
	let lineObj = patcher.lines[id];
	let startC, destC, start, dest;
	if (isSrc) {
		startC = offset;
		destC = $("#" + lineObj.dest[0]).find(".object-inlet").eq(lineObj.dest[1]).offset();
		start = [startC.left, startC.top];
		dest = [destC.left + 5.5, destC.top + 5.5];
	} else {
		startC = $("#" + lineObj.src[0]).find(".object-outlet").eq(lineObj.src[1]).offset();
		destC = offset;
		start = [startC.left + 5.5, startC.top + 5.5];
		dest = [destC.left, destC.top];
	}
	let divStyle = {
		"left": Math.min(start[0], dest[0]) - 5,
		"top": Math.min(start[1], dest[1]) - 10,
		"width": Math.abs(start[0] - dest[0]) + 10,
		"height": Math.abs(start[1] - dest[1]) + 20,
	};
	let dStart = [start[0] - divStyle.left, start[1] - divStyle.top];
	let dMid = [divStyle.width / 2, divStyle.height / 2];
	let dDest = [dest[0] - divStyle.left, dest[1] - divStyle.top];
	let dBezier = [dStart[0] * 0.8 + dMid[0] * 0.2, start[1] - divStyle.top + divStyle.height / 5];
	if (dBezier[1] > divStyle.height) dBezier[1] = divStyle.height;
	let d = ["M", dStart[0], dStart[1], "Q", dBezier[0], dBezier[1], ",", dMid[0], dMid[1], "T", dDest[0], dDest[1]];
	$("#" + id).css(divStyle)
		.find("svg").width(divStyle.width).height(divStyle.height)
		.find("path").attr("d", d.join(" "))
}

let updateLine = function (id) {
	let lineObj = patcher.lines[id];
	let startC = $("#" + lineObj.src[0]).find(".object-outlet").eq(lineObj.src[1]).offset();
	let destC = $("#" + lineObj.dest[0]).find(".object-inlet").eq(lineObj.dest[1]).offset();
	let start = [startC.left + 5.5, startC.top + 5.5];
	let dest = [destC.left + 5.5, destC.top + 5.5];
	let divStyle = {
		"left": Math.min(start[0], dest[0]) - 5,
		"top": Math.min(start[1], dest[1]) - 10,
		"width": Math.abs(start[0] - dest[0]) + 10,
		"height": Math.abs(start[1] - dest[1]) + 20,
	};
	let dStart = [start[0] - divStyle.left, start[1] - divStyle.top];
	let dMid = [divStyle.width / 2, divStyle.height / 2];
	let dDest = [dest[0] - divStyle.left, dest[1] - divStyle.top];
	let dBezier = [dStart[0] * 0.8 + dMid[0] * 0.2, start[1] - divStyle.top + divStyle.height / 5];
	if (dBezier[1] > divStyle.height) dBezier[1] = divStyle.height;
	let d = ["M", dStart[0], dStart[1], "Q", dBezier[0], dBezier[1], ",", dMid[0], dMid[1], "T", dDest[0], dDest[1]];
	let handlerPos = findHandlerPosLine(id);
	$("#" + id).css(divStyle)
		.find("svg").width(divStyle.width).height(divStyle.height)
		.find("path").attr("d", d.join(" "))
		.parent().siblings(".line-handler-dest").first().css("left", handlerPos[2]).css("top", handlerPos[3])
		.siblings(".line-handler-src").first().css("left", handlerPos[0]).css("top", handlerPos[1]);
}

let updateLineByObj = function (id) {
	let lineIDs = patcher.getLinesByDestID(id).concat(patcher.getLinesBySrcID(id));
	for (let i = 0; i < lineIDs.length; i++) {
		updateLine(lineIDs[i]);
	}
}

let findHandlerPosLine = function (id) {
	let path = $("#" + id).find(".line-path")[0];
	let length = path.getTotalLength();
	let res = [];
	let loc = path.getPointAtLength(10);
	res.push(loc.x);
	res.push(loc.y);
	loc = path.getPointAtLength(length - 10);
	res.push(loc.x);
	res.push(loc.y);
	return res;
}

let findClosestPort = function (offset, findOutlet, exclude) {
	let closest = [];
	let distance;
	$(findOutlet ? ".object-outlet" : ".object-inlet").each((index, element) => {
		let o = $(element).offset();
		let d = Math.pow((o.top - offset.top + 5.5) * (o.top - offset.top + 5.5) + (o.left - offset.left + 5.5) * (o.left - offset.left + 5.5), 0.5);
		
		if (closest.length == 0 || d < distance) {
			let e = [];
			e[0] = $(element).parents(".object").attr("id");
			e[1] = $(element).index();
			if (typeof exclude == "undefined" || e[0] != exclude[0] || e[1] != exclude[1]) {
				closest = e;
				distance = d;
			}
		}
	})

	return distance < 50 ? closest : [];
}
