import { EventEmitter } from "events";
import UIObj from "./UIObj.jsx";

class EmptyObject extends EventEmitter {
    constructor(box, patcher) {
        super();
        this._patcher = patcher;
        this.name = box.name;
        this.boxes = [box.id];
        this.ui = UIObj.Box;
        this.inlets = 1;
        this.outlets = 1;
        this.fn = (data, inlet) => {
            this.outlet(0, data);
        };
    }
    outlet(i, data) {
        this.emit(this.outletLines[i], data);
    }
    destroy() {
        delete this._patcher.data[this.name][this.class];
    }
    addBox(id) {
        this.boxes.push(id);
    }
    removeBox(id) {
        this.boxes.splice(this.boxes.indexOf(id), 1);
        if (this.boxes.length == 0) this.destroy();
    }
    connectedOutlet(outlet, destObj, destInlet, lineID) {}
    connectedInlet(inlet, srcObj, srcOutlet, lineID) {}
    disconnectedOutlet(outlet, destObj, destInlet, lineID) {}
    disconnectedInlet(inlet, srcObj, srcOutlet, lineID) {}
    get outletLines() {
        let lines = [];
        for (let i = 0; i < this.outlets; i++) {
            lines[i] = [];
            for (let j = 0; j < this.boxes; j++) {
                lines[i].concat(this._patcher.getLinesBySrcID(this.boxes[j], i));
            }
        }
        return lines;
    }
    get inletLines() {
        let lines = [];
        for (let i = 0; i < this.inlets; i++) {
            lines[i] = [];
            for (let j = 0; j < this.boxes; j++) {
                lines[i].concat(this._patcher.getLinesByDestID(this.boxes[j], i));
            }
        }
        return lines;
    }
    get class() {
        return this.constructor.name;
    }
}

class InvalidObject extends EmptyObject {
    constructor(box, patcher) {
        super(box, patcher);
        // this.ui = UIObj.InvalidBox;
        this.inlets = 0;
        this.outlets = 0;
        this.fn = (data, inlet) => {};
    }


}
export default {
    EmptyObject,
    InvalidObject
}